'''
filter_all.py

Author:
1. Katelin Lauren Avenir | kavenir
2. Aaron Czulada | aczulada
3. Radhika Govindarajan | rgovind2
4. Phrimphissa Kraikhun | pkraikhu
5. Yue Sun | yuesun

This module filters the listings dataframe according to the specified criteria:

The main function, filter, takes 
- listing dataframe
- neighborhood dataframe
- supermarket dataframe
- preferred number of bedroom
- preferred number of bathroom
- minimum leasing price
- maximum leasing price
- preferred neighborhood #1
- preferred neighborhood #2
- preferred neighborhood #3
- maximum distance to the nearest supermarket

and return the matching listing dataframe

Import: get_data, clean_listing
Imported to: GROUP_A4_APARTNERS

'''

from shapely.geometry import Point
from shapely.geometry.polygon import Polygon
import geopy.distance
import get_data
import numpy as np
import pandas as pd
import clean_listing

#filter the listing according to users preferred number of bed, bath and price range
def filter_bd_ba_price(df, bed,bath, minimum_price, maximum_price):
    listing_df = df
    filtered_bd_ba_price = listing_df[
        (listing_df['min_bedroom'] >= bed) & (listing_df['max_bedroom'] <= bed) & 
        (listing_df['min_bathroom'] >= bath) & (listing_df['max_bathroom'] <= bath) & 
        (listing_df['price_min'] >= minimum_price) & (listing_df['price_max'] <= maximum_price)]

    return filtered_bd_ba_price

def compare_coordinate(list_co, p):
    polygon = Polygon([tuple(n) for n in list_co])
    point = Point(p[1],p[0])
    return polygon.contains(point)

def distance(p1, p2):
    return (geopy.distance.geodesic(p1, p2).miles)

#filter listing according to the preferred distance to the nearest supermarket
def filter_supermarket(listing_df, supermarket_df, d ):
    supermarket_df['supermarket_coordinate'] = list(zip(supermarket_df['latitude'], supermarket_df['longitude']))
    min_distance = []
    for p in listing_df['listing_coordinates']:
        distance_to_all = [distance(p,sm) for sm in supermarket_df['supermarket_coordinate']]
        min_distance.append(min(distance_to_all))
    listing_df['min_distance_to_supermarket'] = min_distance
    listing_df = listing_df[listing_df.min_distance_to_supermarket <= d]

    return listing_df

#filter listing according to the preferred neighborhoods
def filter_neighborhood(listing_df, neighborhood_df, n1, n2, n3):
    listing_neighborhood = []

    for p in listing_df['listing_coordinates']:
        neighborhood_df['temp'] = [compare_coordinate(n[0][0],p) for n in neighborhood_df['neighboorhood_coordinates']]
        try:
            listing_neighborhood.append(neighborhood_df.loc[neighborhood_df['temp'] == True].iloc[0].neighborhood_name)   
        except:
            listing_neighborhood.append(np.NaN)
    
    listing_df['listing_neighborhood'] = listing_neighborhood
    neighborhood_df_sub = neighborhood_df[['neighborhood_name', 'neighborhood_crime_rate']]
    listing_df = pd.merge(listing_df, neighborhood_df_sub, how = 'inner', left_on = 'listing_neighborhood', right_on = 'neighborhood_name')
    listing_df.dropna(subset=['listing_neighborhood'], inplace = True)

    listing_df = listing_df[(listing_df.listing_neighborhood == n1)|(listing_df.listing_neighborhood == n2)|(listing_df.listing_neighborhood == n3)]

    return listing_df


def filter(l_df,n_df,s_df,bed=0,bath=0.5, minimum_price=0, maximum_price=0, n1="", n2="", n3="", distance=0.1):
    filtered_all = filter_bd_ba_price(l_df, bed, bath, minimum_price, maximum_price)
    filtered_all = filter_neighborhood(filtered_all,n_df, n1, n2, n3)
    filtered_all = filter_supermarket(filtered_all, s_df, distance)
    
    return filtered_all



if __name__ == '__main__':
    listing_df = get_data.get_listing(1000)
    listing_df = clean_listing.clean_listing(listing_df)
    neighborhood_df = get_data.get_neighborhood()
    supermarket_df = get_data.get_supermarket()
    
    print(filter(listing_df, neighborhood_df, supermarket_df, 1, 1, 900, 1500, 'Ryan Dr / Cherrydell Dr', 'Gayly', 'Shadyside', 4))





    




