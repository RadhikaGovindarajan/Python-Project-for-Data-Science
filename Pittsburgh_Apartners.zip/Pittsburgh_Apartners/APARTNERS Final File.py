'''
GROUP_A4_APARTNERS.py

Author:
1. Katelin Lauren Avenir | kavenir
2. Aaron Czulada | aczulada
3. Radhika Govindarajan | rgovind2
4. Phrimphissa Kraikhun | pkraikhu
5. Yue Sun | yuesun

This is the main file for Pittsburgh Apartners project.
It ties the input and ouput with UI. 

Import: get_data, clean_listing, filter_all
Imported to: -

'''

import tkinter as tk
from tkinter import ttk
import get_data
import clean_listing
import filter_all

def selected_bd():
    return bd_select.get()

def selected_ba():
    return ba_select.get()

def selected_n1():
    return n1_select.get()

def selected_n2():
    return n2_select.get()

def selected_n3():
    return n3_select.get()

def selected_min_price():
    return price_min_select.get()

def selected_max_price():
    return price_max_select.get()

def selected_grocery_distance():
    return grocery_distance_select.get()

def search():
    global listing_df
    global neighborhood_df
    global supermarket_df
    global resultVar
    global result

    bd = int(selected_bd())
    ba = float(selected_ba())
    min_price = int(selected_min_price())
    max_price = int(selected_max_price())
    n1 = selected_n1()
    n2 = selected_n2()
    n3 = selected_n3()
    distance_to_grocery = float(selected_grocery_distance())

    # bd = 1
    # ba = 1
    # min_price = 900
    # max_price = 1500
    # n1 = 'Shadyside'
    # n2 = 'Bloomfield'
    # n3 = 'West Oakland'
    # distance_to_grocery = 2.0
    
    listing_result = filter_all.filter(listing_df, neighborhood_df, supermarket_df, bd, ba, min_price, max_price, n1, n2, n3, distance_to_grocery)

    print()
    print("Search result")
    print(listing_result)

    root = tk.Tk()
    root.geometry("500x500")
    root.title("Search Result")

    # root.title("Search Result")
    container = ttk.Frame(root)
    canvas = tk.Canvas(container, bg='white')
    scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
    scrollable_frame = ttk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

    canvas.configure(yscrollcommand=scrollbar.set)  


    if len(listing_result)==0:

        ttk.Label(scrollable_frame, text="Sorry, there's no available listing on your specified criteria.\nPlease try again with different requirement.").pack()

    else:
        for i in range(len(listing_result)):

            neighborhood = listing_result.iloc[i, 12]
            crime_rate = listing_result.iloc[i, 14]
            address = listing_result.iloc[i, 0]
            price = listing_result.iloc[i, 2]
            bed = listing_result.iloc[i, 4]
            bath = listing_result.iloc[i, 5]
            distance_to_grocery = listing_result.iloc[i, 15]
            temp = "Neighborhood: {:<30s}\tCrime rate: {:d}\nAddress: {:<50s}\nPrice: {:<30s}\nBed: {:<20s}\tBath: {:<20s}\nDistance to supermarket: {:.2f} miles".format(neighborhood, crime_rate, address, price, bed, bath, distance_to_grocery)
            tk.Label(scrollable_frame, text=str(i+1), justify=tk.LEFT, bg="#fce6e6").pack(fill="both")
            tk.Label(scrollable_frame, text=temp, justify=tk.LEFT).pack(fill="both")

    
    container.pack(side="left", fill="both", expand=True)
    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    root.mainloop()

def close_app():
    window.destroy()
    exit()

# Get the data
listing_df = get_data.get_listing(1000)
listing_df = clean_listing.clean_listing(listing_df)
neighborhood_df = get_data.get_neighborhood()
supermarket_df = get_data.get_supermarket()


window = tk.Tk()
window.title("Pittsburgh Apartners")

# Logo
logo = tk.PhotoImage(file="logo.png")
tk.Label(window, image=logo).grid(row=0, columnspan=3, sticky=tk.N)

# Neighborhood
tk.Label(window, text='Neighborhood').grid(row=1, column=0, sticky=tk.W)
neighborhood_options = list(neighborhood_df.neighborhood_name.unique())
neighborhood_options.sort()
n1_select = tk.StringVar()
n1_select.set(neighborhood_options[0])
n1_dropdown = tk.OptionMenu(window, n1_select, *neighborhood_options)
n1_dropdown.grid(row=1, column=1, sticky=tk.W)
n1_dropdown.config(width=20)

n2_select = tk.StringVar()
n2_select.set(neighborhood_options[0])
n2_dropdown = tk.OptionMenu(window, n2_select, *neighborhood_options)
n2_dropdown.grid(row=1, column=2, sticky=tk.W)
n2_dropdown.config(width=20)

n3_select = tk.StringVar()
n3_select.set(neighborhood_options[0])
n3_dropdown = tk.OptionMenu(window, n3_select, *neighborhood_options)
n3_dropdown.grid(row=1, column=3, sticky=tk.W)
n3_dropdown.config(width=20)

# Price Range
price_min_select = tk.StringVar()
price_min_select.set("0")
tk.Label(window, text='Minimum price').grid(row=2, column=0, sticky=tk.W)
tk.Entry(window, textvariable=price_min_select).grid(row=2, column=1, sticky=tk.W)
price_max_select = tk.StringVar()
price_max_select.set("0")
tk.Label(window, text='Maximum price').grid(row=2, column=2, sticky=tk.W)
tk.Entry(window, textvariable=price_max_select).grid(row=2, column=3, sticky=tk.W)

# Number of Bedroom
tk.Label(window, text='Bedroom').grid(row=3, column=0, sticky=tk.W)
bd_options = list(listing_df.max_bedroom.unique())
bd_options.sort()
try: bd_options.remove(-1)
except: pass
bd_select = tk.StringVar()
bd_select.set(bd_options[0])
bd_dropdown = tk.OptionMenu(window, bd_select, *bd_options)
bd_dropdown.grid(row=3, column=1, sticky=tk.W)
bd_dropdown.config(width=20)

# Number of Bathroom
tk.Label(window, text='Bathroom').grid(row=4, column=0, sticky=tk.W)
ba_options = list(listing_df.max_bathroom.unique())
ba_options.sort()
ba_select = tk.StringVar()
ba_select.set(ba_options[0])
ba_dropdown = tk.OptionMenu(window, ba_select, *ba_options)
ba_dropdown.grid(row=4, column=1, sticky=tk.W)
ba_dropdown.config(width=20)

# Distance to nearest grocery store
grocery_distance_select = tk.StringVar()
grocery_distance_select.set("0")
tk.Label(window, text='Distance to closest grocery store (miles)').grid(row=5, column=0, sticky=tk.W)
tk.Entry(window, textvariable=grocery_distance_select).grid(row=5, column=1, sticky=tk.W)

# Submit search button
submit_button = tk.Button(window, text = "Click here to find your matches", command = search)
submit_button.grid(row=6, column=0, sticky=tk.W)

exit_button = tk.Button(window, text = "Click to EXIT", command = close_app)
exit_button.grid(row=7, column=0, sticky=tk.W)

window.mainloop()

