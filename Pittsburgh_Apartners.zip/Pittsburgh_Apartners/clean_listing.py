'''
clean_listing.py

Author:
1. Katelin Lauren Avenir | kavenir
2. Aaron Czulada | aczulada
3. Radhika Govindarajan | rgovind2
4. Phrimphissa Kraikhun | pkraikhu
5. Yue Sun | yuesun

This module prepare the listing data for the filtering process

Import: get_data
Imported to: filter_all, GROUP_A4_APARTNERS

'''

import re
import get_data 


def min_bedroom(row):  
    if row['bedroom_num_range'] == '2bd':
        return 2
    elif row['bedroom_num_range'] == '3bd':
        return 3
    elif row['bedroom_num_range'] == '1bd':
        return 1
    elif row['bedroom_num_range'] == '3bd':
        return 3
    elif row['bedroom_num_range'] == '1-2bd':
        return 1
    elif row['bedroom_num_range'] == 'Studio-2bd':
        return 0
    elif row['bedroom_num_range'] == 'Studio':
        return 0
    elif row['bedroom_num_range'] == 'Studio-1bd':
        return 0
    elif row['bedroom_num_range'] == '1-3bd':
        return 1
    elif row['bedroom_num_range'] == '5bd':
        return 5
    elif row['bedroom_num_range'] == '6bd':
        return 6
    elif row['bedroom_num_range'] == 'Studio-3bd':
        return 0
    elif row['bedroom_num_range'] == '2-3bd':
        return 2
    elif row['bedroom_num_range'] == '7bd':
        return 7
    else: 
        return -1

def max_bedroom(row):  
    if row['bedroom_num_range'] == '2bd':
        return 2
    elif row['bedroom_num_range'] == '3bd':
        return 3
    elif row['bedroom_num_range'] == '1bd':
        return 1
    elif row['bedroom_num_range'] == '3bd':
        return 3
    elif row['bedroom_num_range'] == '1-2bd':
        return 2
    elif row['bedroom_num_range'] == 'Studio-2bd':
        return 2
    elif row['bedroom_num_range'] == 'Studio':
        return 0
    elif row['bedroom_num_range'] == 'Studio-1bd':
        return 1
    elif row['bedroom_num_range'] == '1-3bd':
        return 3
    elif row['bedroom_num_range'] == '5bd':
        return 5
    elif row['bedroom_num_range'] == '6bd':
        return 6
    elif row['bedroom_num_range'] == 'Studio-3bd':
        return 3
    elif row['bedroom_num_range'] == '2-3bd':
        return 3
    elif row['bedroom_num_range'] == '7bd':
        return 7
    else: 
        return -1

def min_bathroom(row):  
    if row['bathroom_num_range'] == '1ba':
        return 1
    elif row['bathroom_num_range'] == '3ba':
        return 3
    elif row['bathroom_num_range'] == '1.5ba':
        return 1.5
    elif row['bathroom_num_range'] == '1-2ba':
        return 1
    elif row['bathroom_num_range'] == '2.5ba':
        return 2.5
    elif row['bathroom_num_range'] == '3ba':
        return 3
    elif row['bathroom_num_range'] == '1-1.5ba':
        return 1
    elif row['bathroom_num_range'] == '1-2.5ba':
        return 1
    elif row['bathroom_num_range'] == '0ba':
        return 0
    elif row['bathroom_num_range'] == '3.5ba':
        return 3.5
    elif row['bathroom_num_range'] == '4ba':
        return 4
    elif row['bathroom_num_range'] == '1-3ba':
        return 1
    elif row['bathroom_num_range'] == '5ba':
        return 5
    else: 
        return 0

def max_bathroom(row):  
    if row['bathroom_num_range'] == '1ba':
        return 1
    elif row['bathroom_num_range'] == '3ba':
        return 3
    elif row['bathroom_num_range'] == '1.5ba':
        return 1.5
    elif row['bathroom_num_range'] == '1-2ba':
        return 2
    elif row['bathroom_num_range'] == '2.5ba':
        return 2.5
    elif row['bathroom_num_range'] == '3ba':
        return 3
    elif row['bathroom_num_range'] == '1-1.5ba':
        return 1.5
    elif row['bathroom_num_range'] == '1-2.5ba':
        return 2.5
    elif row['bathroom_num_range'] == '0ba':
        return 0
    elif row['bathroom_num_range'] == '3.5ba':
        return 3.5
    elif row['bathroom_num_range'] == '4ba':
        return 4
    elif row['bathroom_num_range'] == '1-3ba':
        return 3
    elif row['bathroom_num_range'] == '5ba':
        return 5
    else: 
        return 0

def find_number(text):
    num = re.findall(r'[0-9]+',text)
    return "".join(num)

def clean_listing(l_df): 
    listing_df = l_df.copy()
    
    #Create additional columns min_bedroom, max_bedroom, min_bathroom, max_bathroom based on exisiting columns: bedroom_num_range, bathroom_num_range

    listing_df['min_bedroom'] = listing_df.apply(lambda row: min_bedroom(row), axis=1)
    listing_df['max_bedroom'] = listing_df.apply(lambda row: max_bedroom(row), axis=1)
    listing_df['min_bathroom'] = listing_df.apply(lambda row: min_bathroom(row), axis=1)
    listing_df['max_bathroom'] = listing_df.apply(lambda row: max_bathroom(row), axis=1)

    # create temporary column, 'new_column', for extracting minimum and maximum price range from existing column price_range
    
    listing_df['new_column']=listing_df['price_range'].apply(lambda x: find_number(x))
    
    # extract price_min and price_max for columns that have a range of numbers in price_range column
    listing_df["price_min"] = listing_df["price_range"].str.extract("(.*-)", expand=True)
    listing_df['price_min']=listing_df['price_min'].str.extractall('(\d+)').unstack().fillna('').sum(axis=1).astype(int)
    listing_df["price_max"] = listing_df["price_range"].str.extract("(-.*)", expand=True)
    listing_df["price_max"]=listing_df["price_max"].str.extractall('(\d+)').unstack().fillna('').sum(axis=1).astype(int)
    
    # fill in NULL values in price_min and price_max columns using new_column
    listing_df['price_min'] = listing_df['price_min'].fillna(listing_df['new_column']).astype(int)
    listing_df['price_max'] = listing_df['price_max'].fillna(listing_df['new_column']).astype(int)

    # drop 'new_column' which was a temporary column 
    listing_df = listing_df.drop('new_column', axis=1)
    
    return listing_df

if __name__ == '__main__':
    listing_df = get_data.get_listing(100)
    clean_data = clean_listing(listing_df)
    print(clean_data.head())