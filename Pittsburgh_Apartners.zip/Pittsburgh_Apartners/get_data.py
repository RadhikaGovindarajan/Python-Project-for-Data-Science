'''
get_data.py

Author:
1. Katelin Lauren Avenir | kavenir
2. Aaron Czulada | aczulada
3. Radhika Govindarajan | rgovind2
4. Phrimphissa Kraikhun | pkraikhu
5. Yue Sun | yuesun

This module contains 3 functions to scrape listing, neighborhood and supermarket data
1. get_listing(n)
    retrive n listing data from https://www.trulia.com/ 
    return dataframe
2. get_neighborhood()
    retrive neighborhood data from https://www.neighborhoodscout.com/pa/pittsburgh/crime 
    return dataframe
3. get_supermarket()
    clean Supermarkets.csv (downloaded from https://catalog.data.gov/dataset/allegheny-county-assets)
    return dataframe

Import: -
Imported to: GROUP_A4_APARTNERS

'''


import numpy as np
import pandas as pd
import requests
import json

def get_supermarket():

    #read file
    df = pd.read_csv('Supermarkets.csv', encoding='utf-8')
    # this dataset was obtained from https://catalog.data.gov/dataset/allegheny-county-assets, a list of Allegheny County supermarkets

    # Getting the total number of duplicates
    df['primary_key_from_rocket'].duplicated().sum()

    # getting rid of non-Pittsburgh cities 
    df = df[df.city == 'Pittsburgh']
    df1 = df[(df['name'] != 'Murray Avenue Kosher')]
    df2 = df1[(df1['name'] != 'Dollar Tree #5553')]
    df3 = df2[(df2['name'] != 'Gurung Brothers ')]
    df4 = df3.drop(75)
    supermarket_df = df4[pd.notnull(df4['latitude'])]
    print("successfully getting supermarket data")

    return supermarket_df

def get_neighborhood():
    num_vertices = []
    crime_rate = []
    coordinates = []
    name = []

    headers = {
        'Referer': 'https://map_iframe.neighborhoodscout.com/',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
    }

    response = requests.get('https://production-nscout-static-lrsdmrzmrhqefpb9o.netdna-ssl.com/polygons/bundled_features/cities/14278.json', headers=headers)

    for item in response.json():
        data = json.loads(item)

        name.append(data.get("properties").get("name")[16:-1]) #get neighborhood name
        num_vertices.append(data.get("geometry").get("num_vertices")) #get number of vertices
        coordinates.append(data.get("geometry").get("coordinates")) #get coordinates
        crime_rate.append(data.get("properties").get("c")) #get crime rate 0-9

    neighborhood_df = pd.DataFrame({
        'neighborhood_name': name, 
        'neighboorhood_coordinates': coordinates, 
        'num_of_verticies': num_vertices, 
        'neighborhood_crime_rate': crime_rate})

    neighborhood_df.head()
    print("successfully getting neighborhood data")
    #print(neighborhood_df.head())

    return neighborhood_df

def get_listing(n):
    headers = {
        'authority': 'www.trulia.com',
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'origin': 'https://www.trulia.com',
        'referer': 'https://www.trulia.com/for_rent/Pittsburgh,PA/',
        'sec-ch-ua': '"Google Chrome";v="105", "Not)A;Brand";v="8", "Chromium";v="105"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
        'x-bc-buildercommunitydata': '1',
        'x-contextual-highlights': '1',
        'x-csrf-token': 'D7ma5TT8--PKcmjvGUwfxx9iKh9qtSMcLkbk',
        'x-papi-fall-back-disabled': '0',
        'x-pdc-api-enabled': '1',
        'x-rc-bls': '1',
        'x-request-id': 'client-8e7ad109-873b-45c0-9232-c33639b48c00',
        'x-zg-search-enabled': '1',
    }

    params = {
        'opname': 'WEB_searchResultsMapQuery',
        'transactionId': 'client-8e7ad109-873b-45c0-9232-c33639b48c00',
    }

    json_data = {
        'operationName': 'WEB_searchResultsMapQuery',
        'variables': {
            'isSwipeableFactsEnabled': True,
            'heroImageFallbacks': [
                'STREET_VIEW',
                'SATELLITE_VIEW',
            ],
            'searchDetails': {
                'searchType': 'FOR_RENT',
                'location': {
                    'cities': [
                        {
                            'city': 'Pittsburgh',
                            'state': 'PA',
                        },
                    ],
                },
                'filters': {
                    'sort': {
                        'type': 'RENTAL_PRIORITY_SCORE',
                        'ascending': False,
                    },
                    'page': 1,
                    'limit': n,
                    'propertyTypes': [],
                    'listingTypes': [],
                    'pets': [],
                    'rentalListingTags': [],
                    'foreclosureTypes': [],
                    'buildingAmenities': [],
                    'unitAmenities': [],
                    'landlordPays': [],
                    'propertyAmenityTypes': [],
                },
            },
            'includeOffMarket': False,
            'includeLocationPolygons': True,
            'isSPA': False,
            'includeNearBy': True,
        },
        'query': 'query WEB_searchResultsMapQuery($searchDetails: SEARCHDETAILS_Input!, $heroImageFallbacks: [MEDIA_HeroImageFallbackTypes!], $includeOffMarket: Boolean!, $includeLocationPolygons: Boolean!, $isSPA: Boolean!, $includeNearBy: Boolean!, $isSwipeableFactsEnabled: Boolean = false) {\n  searchResultMap: searchHomesByDetails(searchDetails: $searchDetails, includeNearBy: $includeNearBy) {\n    ...SearchResultsMapClientFragment\n    __typename\n  }\n  offMarketHomes: searchOffMarketHomes(searchDetails: $searchDetails) @include(if: $includeOffMarket) {\n    ...HomeMarkerLayersContainerFragment\n    ...HoverCardLayerFragment\n    __typename\n  }\n}\n\nfragment SearchResultsMapClientFragment on SEARCH_Result {\n  ...HomeMarkerLayersContainerFragment\n  ...HoverCardLayerFragment\n  ...SearchLocationBoundaryFragment @include(if: $includeLocationPolygons)\n  ...SchoolSearchMarkerLayerFragment\n  ...TransitLayerFragment\n  __typename\n}\n\nfragment HomeMarkerLayersContainerFragment on SEARCH_Result {\n  ...HomeMarkersLayerFragment\n  __typename\n}\n\nfragment HomeMarkersLayerFragment on SEARCH_Result {\n  homes {\n    location {\n      coordinates {\n        latitude\n        longitude\n        __typename\n      }\n      __typename\n    }\n    url\n    metadata {\n      compositeId\n      __typename\n    }\n    ...HomeMarkerFragment\n    __typename\n  }\n  nearByHomes {\n    ...HomeMarkerFragment\n    __typename\n  }\n  __typename\n}\n\nfragment HomeMarkerFragment on HOME_Details {\n  media {\n    hasThreeDHome\n    __typename\n  }\n  location {\n    coordinates {\n      latitude\n      longitude\n      __typename\n    }\n    __typename\n  }\n  displayFlags {\n    enableMapPin\n    __typename\n  }\n  price {\n    calloutMarkerPrice: formattedPrice(formatType: SHORT_ABBREVIATION)\n    __typename\n  }\n  url\n  ... on HOME_Property {\n    activeForSaleListing {\n      openHouses {\n        formattedDay\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  ...HomeDetailsTopThirdFragment @include(if: $isSPA)\n  __typename\n}\n\nfragment HomeDetailsTopThirdFragment on HOME_Details {\n  bathrooms {\n    summaryBathrooms: formattedValue(formatType: COMMON_ABBREVIATION)\n    __typename\n  }\n  bedrooms {\n    summaryBedrooms: formattedValue(formatType: COMMON_ABBREVIATION)\n    __typename\n  }\n  floorSpace {\n    formattedDimension\n    __typename\n  }\n  location {\n    city\n    coordinates {\n      latitude\n      longitude\n      __typename\n    }\n    neighborhoodName\n    stateCode\n    zipCode\n    cityStateZipAddress: formattedLocation(formatType: CITY_STATE_ZIP)\n    homeFormattedAddress: formattedLocation\n    summaryFormattedLocation: formattedLocation(formatType: STREET_COMMUNITY_BUILDER)\n    __typename\n  }\n  media {\n    metaTagHeroImages: heroImage(fallbacks: $heroImageFallbacks) {\n      url {\n        desktop: custom(size: {width: 2048, height: 200})\n        __typename\n      }\n      __typename\n    }\n    topThirdHeroImages: heroImage(fallbacks: $heroImageFallbacks) {\n      __typename\n      url {\n        extraSmallSrc: custom(size: {width: 375, height: 275})\n        smallSrc: custom(size: {width: 570, height: 275})\n        mediumSrc: custom(size: {width: 768, height: 500})\n        largeSrc: custom(size: {width: 992, height: 500})\n        hiDipExtraSmallSrc: custom(size: {width: 1125, height: 825})\n        hiDpiSmallSrc: custom(size: {width: 1710, height: 825})\n        hiDpiMediumSrc: custom(size: {width: 2048, height: 1536})\n        __typename\n      }\n      webpUrl: url(compression: webp) {\n        extraSmallWebpSrc: custom(size: {width: 375, height: 275})\n        smallWebpSrc: custom(size: {width: 570, height: 275})\n        mediumWebpSrc: custom(size: {width: 768, height: 500})\n        largeWebpSrc: custom(size: {width: 992, height: 500})\n        hiDipExtraSmallWebpSrc: custom(size: {width: 1125, height: 825})\n        hiDpiSmallWebpSrc: custom(size: {width: 1710, height: 825})\n        hiDpiMediumWebpSrc: custom(size: {width: 2048, height: 1536})\n        __typename\n      }\n    }\n    totalPhotoCount\n    __typename\n  }\n  metadata {\n    compositeId\n    currentListingId\n    __typename\n  }\n  pageText {\n    title\n    metaDescription\n    __typename\n  }\n  price {\n    formattedPrice\n    ... on HOME_LastSoldPrice {\n      formattedPriceDifferencePercent\n      formattedSoldDate(dateFormat: "MMM D, YYYY")\n      listingPrice {\n        formattedPrice(formatType: SHORT_ABBREVIATION)\n        __typename\n      }\n      priceDifferencePercent\n      pricePerDimension {\n        formattedDimension\n        __typename\n      }\n      __typename\n    }\n    ... on HOME_ForeclosureEstimatePrice {\n      price\n      typeDescription\n      __typename\n    }\n    ... on HOME_PriceRange {\n      currencyCode\n      max\n      min\n      __typename\n    }\n    ... on HOME_SinglePrice {\n      currencyCode\n      price\n      __typename\n    }\n    __typename\n  }\n  tracking {\n    key\n    value\n    __typename\n  }\n  url\n  ... on HOME_Property {\n    currentStatus {\n      isOffMarket\n      isRecentlySold\n      isForeclosure\n      isActiveForRent\n      isActiveForSale\n      isRecentlyRented\n      label\n      __typename\n    }\n    __typename\n  }\n  ... on HOME_RentalCommunity {\n    location {\n      rentalCommunityFormattedLocation: formattedLocation(formatType: STREET_COMMUNITY_NAME)\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment HoverCardLayerFragment on SEARCH_Result {\n  homes {\n    ...HomeHoverCardFragment\n    __typename\n  }\n  nearByHomes {\n    ...HomeHoverCardFragment\n    __typename\n  }\n  __typename\n}\n\nfragment HomeHoverCardFragment on HOME_Details {\n  ...HomeDetailsCardFragment\n  ...HomeDetailsCardHeroFragment\n  ...HomeDetailsCardPhotosFragment\n  ...HomeDetailsGroupInsightsFragment @include(if: $isSwipeableFactsEnabled)\n  location {\n    coordinates {\n      latitude\n      longitude\n      __typename\n    }\n    __typename\n  }\n  displayFlags {\n    enableMapPin\n    showMLSLogoOnMapMarkerCard\n    __typename\n  }\n  __typename\n}\n\nfragment HomeDetailsCardFragment on HOME_Details {\n  __typename\n  location {\n    city\n    stateCode\n    zipCode\n    fullLocation: formattedLocation(formatType: STREET_CITY_STATE_ZIP)\n    partialLocation: formattedLocation(formatType: STREET_ONLY)\n    __typename\n  }\n  price {\n    formattedPrice\n    __typename\n  }\n  url\n  tags(include: MINIMAL) {\n    level\n    formattedName\n    icon {\n      vectorImage {\n        svg\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  fullTags: tags {\n    level\n    formattedName\n    icon {\n      vectorImage {\n        svg\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  floorSpace {\n    formattedDimension\n    __typename\n  }\n  lotSize {\n    ... on HOME_SingleDimension {\n      formattedDimension(minDecimalDigits: 2, maxDecimalDigits: 2)\n      __typename\n    }\n    __typename\n  }\n  bedrooms {\n    formattedValue(formatType: TWO_LETTER_ABBREVIATION)\n    __typename\n  }\n  bathrooms {\n    formattedValue(formatType: TWO_LETTER_ABBREVIATION)\n    __typename\n  }\n  isSaveable\n  preferences {\n    isSaved\n    isSavedByCoShopper @include(if: false)\n    __typename\n  }\n  metadata {\n    compositeId\n    legacyIdForSave\n    __typename\n  }\n  tracking {\n    key\n    value\n    __typename\n  }\n  displayFlags {\n    showMLSLogoOnListingCard\n    addAttributionProminenceOnListCard\n    __typename\n  }\n  ... on HOME_RoomForRent {\n    numberOfRoommates\n    availableDate: formattedAvailableDate(dateFormat: "MMM D")\n    providerListingId\n    __typename\n  }\n  ... on HOME_RentalCommunity {\n    activeListing {\n      provider {\n        summary(formatType: SHORT)\n        listingSource {\n          logoUrl\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    location {\n      communityLocation: formattedLocation(formatType: STREET_COMMUNITY_NAME)\n      __typename\n    }\n    providerListingId\n    __typename\n  }\n  ... on HOME_Property {\n    currentStatus {\n      isRecentlySold\n      isRecentlyRented\n      isActiveForRent\n      isActiveForSale\n      isOffMarket\n      isForeclosure\n      __typename\n    }\n    priceChange {\n      priceChangeDirection\n      __typename\n    }\n    activeListing {\n      provider {\n        summary(formatType: SHORT)\n        extraShortSummary: summary(formatType: EXTRA_SHORT)\n        listingSource {\n          logoUrl\n          __typename\n        }\n        __typename\n      }\n      dateListed\n      __typename\n    }\n    lastSold {\n      provider {\n        summary(formatType: SHORT)\n        extraShortSummary: summary(formatType: EXTRA_SHORT)\n        listingSource {\n          logoUrl\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    providerListingId\n    __typename\n  }\n  ... on HOME_FloorPlan {\n    priceChange {\n      priceChangeDirection\n      __typename\n    }\n    provider {\n      summary(formatType: SHORT)\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment HomeDetailsCardHeroFragment on HOME_Details {\n  media {\n    heroImage(fallbacks: $heroImageFallbacks) {\n      url {\n        small\n        __typename\n      }\n      webpUrl: url(compression: webp) {\n        small\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment HomeDetailsCardPhotosFragment on HOME_Details {\n  media {\n    __typename\n    heroImage(fallbacks: $heroImageFallbacks) {\n      url {\n        small\n        __typename\n      }\n      webpUrl: url(compression: webp) {\n        small\n        __typename\n      }\n      __typename\n    }\n    photos {\n      url {\n        small\n        __typename\n      }\n      webpUrl: url(compression: webp) {\n        small\n        __typename\n      }\n      __typename\n    }\n  }\n  __typename\n}\n\nfragment HomeDetailsGroupInsightsFragment on HOME_Details {\n  ... on HOME_Property {\n    groupedInsights {\n      insights {\n        ... on HOME_FeatureInsights {\n          insightTags {\n            formattedName\n            __typename\n          }\n          __typename\n        }\n        ... on HOME_SmartInsights {\n          insightTags {\n            formattedName\n            __typename\n          }\n          __typename\n        }\n        ... on HOME_ContextualPhrases {\n          phrases {\n            description\n            __typename\n          }\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment SearchLocationBoundaryFragment on SEARCH_Result {\n  location {\n    encodedPolygon\n    ... on SEARCH_ResultLocationCity {\n      locationId\n      __typename\n    }\n    ... on SEARCH_ResultLocationCounty {\n      locationId\n      __typename\n    }\n    ... on SEARCH_ResultLocationNeighborhood {\n      locationId\n      __typename\n    }\n    ... on SEARCH_ResultLocationPostalCode {\n      locationId\n      __typename\n    }\n    ... on SEARCH_ResultLocationState {\n      locationId\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment SchoolSearchMarkerLayerFragment on SEARCH_Result {\n  schools {\n    ...SchoolMarkersLayerFragment\n    __typename\n  }\n  __typename\n}\n\nfragment SchoolMarkersLayerFragment on School {\n  id\n  latitude\n  longitude\n  categories\n  ...SchoolHoverCardFragment\n  __typename\n}\n\nfragment SchoolHoverCardFragment on School {\n  id\n  name\n  gradesRange\n  providerRating {\n    rating\n    __typename\n  }\n  streetAddress\n  studentCount\n  latitude\n  longitude\n  __typename\n}\n\nfragment TransitLayerFragment on SEARCH_Result {\n  transitStations {\n    stationName\n    iconUrl\n    coordinates {\n      latitude\n      longitude\n      __typename\n    }\n    radius\n    __typename\n  }\n  __typename\n}\n',
    }

    response = requests.post('https://www.trulia.com/graphql', params=params, headers=headers, json=json_data)

    data = ""

    #Decode the data from the website from utf-8 and put into one long string

    for item in response:
        item = item.decode("utf-8") 
        data += item


    #Change the string (json) to dictionary
    data = json.loads(data)

    #Empty list for each item
    location = []
    coordinates = []
    price_range = []
    size_range = []
    bedrooms = []
    bathrooms = []

    #Populate the list of each item
    for item in data["data"]['searchResultMap']['homes']:

        location.append(item.get('location').get('fullLocation'))
        coordinates.append([item.get('location').get('coordinates').get('latitude'),item.get('location').get('coordinates').get('longitude')])  
        price_range.append(item.get('price').get('formattedPrice'))
        
        try: 
            size_range.append(item.get('floorSpace').get('formattedDimension'))
        except:
            size_range.append("")

        bedrooms.append(item.get('bedrooms').get('formattedValue'))
        bathrooms.append(item.get('bathrooms').get('formattedValue'))

    #Put the list into the dataframe
    listing_df = pd.DataFrame({
        'listing_street_addresss': location, 
        'listing_coordinates': coordinates, 
        'price_range': price_range, 
        'size_range': size_range,
        'bedroom_num_range': bedrooms,
        'bathroom_num_range': bathrooms})
    
    print("successfully getting listing data")
    #print(listing_df.head())
    return listing_df


if __name__ == '__main__':
    get_neighborhood()
    get_listing(100)
    get_supermarket()


